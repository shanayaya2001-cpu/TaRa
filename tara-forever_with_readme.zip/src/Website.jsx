import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, ArrowRight, Image as ImageIcon, Lock } from "lucide-react";

const Section = ({ id, className = "", children }) => (
  <section id={id} className={`w-full py-20 md:py-28 ${className}`}>
    <div className="mx-auto w-full max-w-7xl px-6 md:px-8">{children}</div>
  </section>
);

export default function Website() {
  const [photos, setPhotos] = useState([]);
  const [unlocked, setUnlocked] = useState(false);
  const [secret, setSecret] = useState("");

  const handlePhotoUpload = (e) => {
    const files = Array.from(e.target.files);
    const urls = files.map((file) => URL.createObjectURL(file));
    setPhotos((prev) => [...prev, ...urls]);
  };

  const checkCode = () => {
    if (secret === "TaRa1211") {
      setUnlocked(true);
    } else {
      alert("Oops! Wrong code. Try again 💖");
    }
  };

  return (
    <div className="min-h-screen bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">
      <header className="sticky top-0 z-50 border-b border-zinc-200/60 bg-white/80 backdrop-blur dark:border-zinc-800/60 dark:bg-zinc-950/60">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 md:px-8">
          <a href="#home" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-pink-600 animate-pulse" />
            <span className="font-semibold text-pink-600">TaRa Forever</span>
          </a>
        </div>
      </header>

      <Section id="home">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="grid items-center gap-10 md:grid-cols-2"
        >
          <div>
            <h1 className="text-4xl font-bold tracking-tight text-pink-600 md:text-6xl">
              TaRa Forever 💕
            </h1>
            <p className="mt-4 max-w-prose text-lg text-zinc-600 dark:text-zinc-400">
              The only way to celebrate Long distance Love😭❤
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button size="lg" className="bg-pink-600 hover:bg-pink-700 animate-bounce">
                Click to see 'Humarai Kahani' <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </motion.div>
      </Section>

      <Section id="moments">
        <h2 className="text-3xl font-bold tracking-tight md:text-4xl text-pink-600 text-center">
          Special Moments
        </h2>
        <div className="mb-6 text-center">
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-pink-300 bg-pink-50 px-4 py-2 text-sm font-medium text-pink-600 hover:bg-pink-100 dark:border-pink-700 dark:bg-pink-800/40">
            <ImageIcon className="h-4 w-4 animate-spin-slow" /> Upload Photos
            <input type="file" accept="image/*" multiple hidden onChange={handlePhotoUpload} />
          </label>
        </div>
        <motion.div layout className="grid gap-4 md:grid-cols-3">
          {photos.map((src, i) => (
            <motion.div
              key={i}
              layout
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="overflow-hidden rounded-2xl border border-pink-200 shadow-sm dark:border-pink-700"
            >
              <img src={src} alt={`memory-${i}`} className="h-64 w-full object-cover" />
            </motion.div>
          ))}
        </motion.div>
      </Section>

      <Section id="secret">
        <h2 className="text-3xl font-bold tracking-tight md:text-4xl text-pink-600 text-center">
          Secret Love Letter
        </h2>
        <AnimatePresence mode="wait">
          {!unlocked ? (
            <motion.div
              key="locked"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5 }}
              className="mx-auto max-w-md text-center space-y-4"
            >
              <Input
                type="password"
                placeholder="Enter secret code"
                value={secret}
                onChange={(e) => setSecret(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && checkCode()}
              />
              <Button onClick={checkCode} className="bg-pink-600 hover:bg-pink-700 w-full animate-bounce">
                <Lock className="mr-2 h-4 w-4" /> Unlock
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="unlocked"
              initial={{ opacity: 0, scale: 0.8, rotate: -10 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 0.8, type: "spring" }}
              className="mx-auto max-w-xl rounded-2xl border border-pink-200 bg-pink-50 p-6 shadow-xl dark:border-pink-700 dark:bg-pink-800/40"
            >
              <p className="text-lg text-pink-700 dark:text-pink-200">
                To MY CUTU KUCHUPUCHU PYAARE SE SIR JIIII... <br />
                (💌 Your full letter goes here 💌)
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </Section>
    </div>
  );
}