# 💕 TaRa Forever

A surprise website made with **React + Vite + TailwindCSS + Framer Motion**.  
Dedicated to love and special memories 💖

---

## 🚀 Getting Started (Local Development)

### 1. Clone this repository
```bash
git clone https://github.com/your-username/tara-forever.git
cd tara-forever
```

### 2. Install dependencies
```bash
npm install
```

### 3. Run development server
```bash
npm run dev
```
Then open [http://localhost:5173](http://localhost:5173) in your browser.

---

## 🌸 Deployment on Vercel

1. Push this project to your GitHub account.
2. Go to [Vercel](https://vercel.com) → **New Project** → Import your GitHub repo.
3. In the build settings:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
4. Click **Deploy** 🎉

Your site will be live at  
```
https://tara-forever.vercel.app
```

---

## 🌸 Deployment on Netlify

1. Push this project to your GitHub account.
2. Go to [Netlify](https://app.netlify.com) → **New site from Git**.
3. Connect your GitHub repo.
4. In the build settings:
   - **Build Command:** `npm run build`
   - **Publish Directory:** `dist`
5. Click **Deploy** 🎉

Your site will be live at  
```
https://tara-forever.netlify.app
```

---

## 🛠 Tech Stack
- [React](https://reactjs.org/)
- [Vite](https://vitejs.dev/)
- [TailwindCSS](https://tailwindcss.com/)
- [Framer Motion](https://www.framer.com/motion/)
- [Lucide React](https://lucide.dev/)

---

## 💖 Features
- Animated homepage  
- Photo upload gallery  
- Secret letter (code: **TaRa1211**)  
- Fully responsive and cute design  

---
